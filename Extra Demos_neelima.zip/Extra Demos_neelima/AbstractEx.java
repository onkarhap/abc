public class AbstractEx {

	public static void main(String[] args) {
		//TrialDerived1 d = new TrialDerived1();
		/*TrialDerived22 d = new TrialDerived22();
		d.method1();
		d.mm();
		*/
	}
		

	}

