
public abstract class TrialBase {
	public abstract void method1();
	public void method2() { System.out.println("Base Concrete");}
	
	TrialBase() {System.out.println("Base Constructor");}
}

