
public abstract class TrialDerived2 extends TrialBase {
	public void method1() {System.out.println("Derived2 Method1");}
	TrialDerived2() {System.out.println("Derived2 Constructor");}
}

