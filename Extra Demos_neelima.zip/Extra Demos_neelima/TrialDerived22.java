
public class TrialDerived22 extends TrialDerived2 {
	public void method1() {System.out.println("Derived22 Method1");}
	public void mm(){System.out.println("Derived22 mm");}

}
