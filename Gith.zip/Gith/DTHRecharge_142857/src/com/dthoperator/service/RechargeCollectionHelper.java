package com.dthoperator.service;
import java.util.*;

import com.dthoperator.bean.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
//importing necessary files

public class RechargeCollectionHelper { 	//creating class named RechargeCollectionHelper
	static List<RechargeDetails> list = new ArrayList<RechargeDetails>();
	static{
		//declaring objects
		RechargeDetails object1=new RechargeDetails("Airtel","5059343234","Monthly",253,5564);
		list.add(object1);
		
		RechargeDetails object2=new RechargeDetails("Reliance","1673256823","Yearly",4294,9315);
		list.add(object2);
		
		RechargeDetails object3=new RechargeDetails("DishTV","8323470400","Quarterly",562,9235);
		list.add(object3);
	}
	//displayRechargeDetails method
	public static void displayRechargeDetails(int transactionID1)
	{
		for(Object object: list)
		{
			RechargeDetails rech=(RechargeDetails)object;
			if(rech.transactionID  ==  transactionID1)
			{
				System.out.println(object);
			}
		}
	}
	//addRechargeDetails method
	public static void addRechargeDetails(RechargeDetails rechargeDetails)
	{
		list.add(rechargeDetails);
	}
}