package com.dthoperator.test;
import com.dthoperator.test.*;
import com.dthoperator.bean.*;
import com.dthoperator.exception.*;
import com.dthoperator.service.*;
//importing necessary files

public class CheckValidation {
	//creating class named Validator
		public void test_Operator() throws RechargeException {
			Assert.assertEquals(true,RechargeDataValidator.validatedthOperator("Airtel"));
		}
		public void test_ConsumerNumber() throws RechargeException {
			Assert.assertEquals(true,RechargeDataValidator.validateConsumerNo("8978675642"));
		}
		public void test_RechargeAmount() throws RechargeException {
			Assert.assertEquals(true,RechargeDataValidator.validateAmount("352"));
		}
		public void test_RechargePlan() throws RechargeException {
			Assert.assertEquals(true,RechargeDataValidator.validatePlan("Monthly"));
		}
	}
