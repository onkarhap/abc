package com.dthoperator.ui;
import java.util.Random;	
import java.util.Scanner;

import com.dthoperator.exception.*;
import com.dthoperator.exception.RechargeException;
import com.dthoperator.ui.RechargeClient;
import com.dthoperator.bean.RechargeDetails;
import com.dthoperator.service.RechargeDataValidator;
import com.dthoperator.service.RechargeCollectionHelper;
//importing necesary files

public class RechargeClient {
	//creating class
	static Scanner scan=new Scanner(System.in);
	public static void main(String[] args) throws RechargeException
	{
		 int ch; //variable declaration
		 while(true) //running while loop to enter choice no.
		 {
		 	System.out.println("Enter your choice- ");
		 	System.out.println("1. Make a Recharge");
		 	System.out.println("2. Display Recharge Details");
		 	System.out.println("3. Exit");

		 	ch=scan.nextInt();
		 	switch(ch)  // using switch case
		 	{
		 	case 1:{
		 		System.out.println("1. Make a Recharge");
		 		recharge(); break;}
		 		
		 	case 2:{System.out.println("2. Display Recharge Details");
		 	
		 	System.out.println("Enter Tranx ID");
		 	int txn_id=scan.nextInt();
		 	RechargeCollectionHelper.displayRechargeDetails(txn_id); break;}
		 		
		 	case 3:{System.exit(0); break;}
		 	
		 	default:{System.out.println("Enter correct choice"); break;}
		 		
		 	}
		 }
	}

	
	public static void recharge() throws RechargeException{	//throwing exception
		
		System.out.println("Enter Details of recharge for Home DTH service"); //user input of details
		int itemNos=2;
		while(itemNos!=0)
		{			
			System.out.println("Select the DTH Operator (Airtel / DishTV / Reliance / TATASky");
			String dth_operator=scan.next();
			try {
			if(!RechargeDataValidator.validatedthOperator(dth_operator))  //validating operator
			{
				System.exit(0);
			}
			
			System.out.println("Enter Registered Consumer No.");
			String consumer_id=scan.next();
			if(!RechargeDataValidator.validateConsumerNo(consumer_id)) 	  //validating consumer no
			{
				System.exit(0);
			}
			
			System.out.println("Select Plan(Monthly / Quaterly / Half yearly / Annual)");
			String consumer_plan=scan.next();

			if(!RechargeDataValidator.validatePlan(consumer_plan))   	//validating consumer plan
			{
				System.exit(0);
			}
			
			System.out.println("Enter Amount (Rs.)");
			String recharge_amount=scan.next();

			if(!RechargeDataValidator.validateAmount(recharge_amount)) 	//validating amount
			{
				System.exit(0);
			}

			
			int amount=Integer.parseInt(recharge_amount);
			Random rand = new Random();
			int transaction_id = rand.nextInt(9999);
			
			RechargeDetails object=new RechargeDetails(dth_operator,consumer_id,consumer_plan,amount,transaction_id);
			RechargeCollectionHelper.addRechargeDetails(object);
			}
			
			catch(RechargeException e)
			{			
			}
			itemNos--;
			if(itemNos==1)
			System.out.println("Enter Details of recharge for office DTH service");
			
		 }	
		}	
	} //end of loop

