package Lab3;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumWebDriver {
	public static void main(String[] args) {
		//System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe" );
		WebDriver driver= new FirefoxDriver();
		String baseurl="http://demo.opencart.com/";
		driver.get(baseurl);
		
// Part 1: Launch Application	
	//Title verify- Your Store	
		String expectedTitle1 = "Your Store";
		String actualTitle1 = "";
		actualTitle1 = driver.getTitle();
		if (actualTitle1.contentEquals(expectedTitle1)){
             System.out.println("Title-Test Passed!");
         } 
        else{
             System.out.println("Title-Test Failed");
         }    
		
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/a/i")).click(); //click My account
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click(); //click register
		
	// Heading verify- Register Account	
		String expectedText2 = "Register Account";
		String actualText2 = driver.findElement(By.cssSelector("#content > h1")).getText();
	
		if (actualText2.contentEquals(expectedText2))        {
             System.out.println("Heading-Test Passed!");
         } 
        else        {
             System.out.println("Heading-Test Failed");
         } 
		
		driver.findElement(By.cssSelector("input.btn.btn-primary")).click(); //continue clicked
		driver.switchTo().alert().accept(); //popup window
		
	 //Warning: You must agree to the Privacy Policy!
     //Continue cssSelector("input.btn.btn-primary")
		String expectedText3 = "Warning: You must agree to the Privacy Policy!";
	 //Warning xpath(".//*[@id='account-register']/div[1]")
		String actualText3 = driver.findElement(By.xpath(".//*[@id='account-register']/div[1]")).getText(); 
		
	 //Check message generated or not
		try{
		    System.out.println(actualText3);
		    }
		    catch(Exception e)
		    {		    	
		    	System.out.println("Warning Message is not generated");
		    }
     //Verify Warning Message
		if (actualText3.contentEquals(expectedText3))        {
             System.out.println("Verify Warning Message-Test Passed!");
         } 
        else{
             System.out.println("Verify Warning Message-Test Failed");
         }
	      
// Part 2: For 'Your Personal Details'	  
		//First Name must be between 1 and 32 characters!
		//Last Name must be between 1 and 32 characters!
		//E-Mail Address does not appear to be valid!
        //Telephone must be between 3 and 32 characters!
	       driver.findElement(By.id("input-firstname")).sendKeys("aaaaaaaaaabbbbbbbbbbccccccccccdddddd");
	       driver.findElement(By.id("input-lastname")).sendKeys("aaaaaaaaaabbbbbbbbbbccccccccccdddddd");
	       driver.findElement(By.name("email")).sendKeys("z@g.c");
	       driver.findElement(By.id("input-telephone")).sendKeys("89");
	       driver.findElement(By.id("input-password")).sendKeys("akg");
	       driver.findElement(By.id("input-confirm")).sendKeys("aaa");
	      driver.findElement(By.name("agree")).click(); //click on agree
	      driver.findElement(By.cssSelector("input.btn.btn-primary")).click(); //continue clicked
	      driver.switchTo().alert().accept(); //popup window-ok
	             
	     //firstname- Check message generated or not
			try{
				String fname= driver.findElement(By.xpath(".//*[@id='account']/div[2]/div/div")).getText();
			    System.out.println(fname);
			    }
			    catch(Exception e)
			    {		    	
			    	System.out.println("Warning Message is not generated");
			    }
		 //lastname- Check message generated or not
			try{
				String lname= driver.findElement(By.xpath(".//*[@id='account']/div[3]/div/div")).getText();
			    System.out.println(lname);
			    }
			    catch(Exception e)
			    {		    	
			    	System.out.println("Warning Message is not generated");
			    }
		 //email- Check message generated or not
			 try{
			    String email= driver.findElement(By.xpath(".//*[@id='account']/div[4]/div/div")).getText();
			    System.out.println(email);
			    }
			    catch(Exception e)
			    {		    	
			    	System.out.println("Warning Message is not generated");
			    } 
		 //telephone- Check message generated or not
			try{
				String phone= driver.findElement(By.xpath(".//*[@id='account']/div[5]/div/div")).getText();
			    System.out.println(phone);
			    }
			    catch(Exception e)
			    {		    	
			    	System.out.println("Warning Message is not generated");
			    }
			
			//driver.findElement(By.linkText("Register")).click(); //again click on Register hyperlink
			   driver.findElement(By.id("input-firstname")).sendKeys("Rahul");
		       driver.findElement(By.id("input-lastname")).sendKeys("Shaw");
		       driver.findElement(By.name("email")).sendKeys("rshaw@gmail.com");
		       driver.findElement(By.id("input-telephone")).sendKeys("8918832689");
		       driver.findElement(By.id("input-password")).sendKeys("shaw");
		       driver.findElement(By.id("input-confirm")).sendKeys("shaw");
		      driver.findElement(By.name("agree")).click(); //click on agree
		      driver.findElement(By.cssSelector("input.btn.btn-primary")).click(); //continue clicked
		      driver.switchTo().alert().accept(); //popup window-ok
		      //continue clicked again
		      driver.findElement(By.xpath(".//*[@id='content']/div/div/a")).click();
		      //Address Book clicked
		      driver.findElement(By.xpath(".//*[@id='column-right']/div/a[4]")).click();
		      //New address clicked
		      driver.findElement(By.linkText("New Address")).click();
		      
		    //Address- sending correct details  
		       driver.findElement(By.xpath(".//*[@id='input-firstname']")).sendKeys("Rahul");
		       driver.findElement(By.xpath(".//*[@id='input-lastname']")).sendKeys("Shaw");
		       driver.findElement(By.xpath(".//*[@id='input-address-1']")).sendKeys("address1");
		       driver.findElement(By.xpath(".//*[@id='input-city']")).sendKeys("kolkata");
		       driver.findElement(By.xpath(".//*[@id='input-postcode']']")).sendKeys("713302");
		      Select country = new Select(driver.findElement(By.id("input-country")));
		   	  country.selectByValue("India");
		   	  Select zone = new Select(driver.findElement(By.name("zone-id")));
		   	  zone.selectByValue("Assam");
		   	   driver.findElement(By.xpath(".//*[@id='content']/form/fieldset/div[10]/div/label[2]/input")).click();
		   	   driver.findElement(By.linkText("Continue")).click();
			
	}		
}
