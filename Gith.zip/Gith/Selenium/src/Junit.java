import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Junit {
	@Before
	public void initialize(){
		System.out.println("Before");
	}
	
	@Test
	public void Test(){
		System.out.println("Test");
	}
	
	@After
	public void After(){
		System.out.println("After");
	}
	
	
}
