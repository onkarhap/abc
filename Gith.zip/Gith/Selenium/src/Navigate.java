import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

public class Navigate {

	public static void main(String[] args){
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumhq.org/");
		driver.navigate().to("https://www.google.com/");
    }
}
