import org.testng.annotations.Test;
import static org.testng.AssertJUnit.assertEquals;


public class Testng {
	@Test
	public void testCheck(){
		String str="Welcome to Capg";
		assertEquals("Welcome to Capg",str);
		
	}
}
