package dayanandTuto;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ExecuteScript {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String stext;
		WebDriver driver=new FirefoxDriver();
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("history.go(0)");
		
		driver.get("file:///D:/Users/ankurgup/Desktop/Old%20Firefox/Selenium/Selenium%20Installations/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/AlertExample.html");
		stext=js.executeScript("return document.title;").toString();
		System.out.println(stext);
		
		driver.findElement(By.name("txtName")).sendKeys("Ankur");
		WebElement button=driver.findElement(By.name("btnAlert"));
		js.executeScript("alert('Hello');");
	}

}
