package dayanandTuto;
import java.net.MalformedURLException;
import java.net.URL;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Hub_node {
	WebDriver driver;
	String baseurl,nodeurl;
	
	@BeforeTest
	public void display() throws MalformedURLException
	{
		baseurl="file:///D:/Users/ankurgup/Desktop/Old%20Firefox/Selenium/Selenium%20Installations/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html";
		nodeurl="http://10.102.52.11:5666/wd/hub";
		DesiredCapabilities t=new DesiredCapabilities().chrome();
		t.setBrowserName("chrome");
		t.setPlatform(Platform.WINDOWS);
		driver= new RemoteWebDriver(new URL(nodeurl),t);	
	}
	
	@AfterTest
	public void aftertest(){
		//driver.close();
	}
	
	@Test
	public void simpletest(){
		driver.get(baseurl);
		Assert.assertEquals("Email Registration Forms",driver.getTitle());
	}
	
	
	
}
