package dayanandTuto;

import static org.testng.AssertJUnit.assertEquals;

import org.testng.annotations.Test;

public class TestngStr {
	@Test
	public void testCheck(){
		String str="Welcome to Capg";
		assertEquals("Welcome to Capg",str);
		
	}
}

