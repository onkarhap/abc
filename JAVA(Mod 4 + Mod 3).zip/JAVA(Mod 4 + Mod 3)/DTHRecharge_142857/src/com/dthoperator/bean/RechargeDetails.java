package com.dthoperator.bean;  //package name

public class RechargeDetails  {
//declaring objects or variables
	String dthOperator;
	String consumerNo;
	String rechargePlan;
	int amount;
	public int transactionID;
	
//**** constructor usage ****	
	public RechargeDetails(String dthOperator,String consumerNo,String rechargePlan,int amount,int transactionID)
	{
		this.dthOperator=dthOperator;
		this.rechargePlan=rechargePlan;
		this.consumerNo=consumerNo;
		this.amount=amount;
		this.transactionID=transactionID;
	}
//toString usage
	@Override
	public String toString() {
		return "RechargeDetails [dthOperator=" + dthOperator + ", consumerNo="
				+ consumerNo + ", rechargePlan=" + rechargePlan + ", amount="
				+ amount + ", transactionID=" + transactionID + "]";
	}

}