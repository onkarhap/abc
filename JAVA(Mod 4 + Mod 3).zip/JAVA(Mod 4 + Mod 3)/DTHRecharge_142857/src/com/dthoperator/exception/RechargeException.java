package com.dthoperator.exception;  //package name

public class RechargeException extends Exception{
	//creating class named RechargeException
	public RechargeException(String name)
	{
		System.out.println("Failed to Recharge.");
		
	}
}