import org.testng.annotations.Test;

public class PriorityCheck {
	
	@Test(priority=0)
	public void Register(){
		System.out.println("Register");
	}
	@Test(priority=2)
	public void mailSend(){
		System.out.println("MailSend");
	}
	@Test(priority=1)
	public void login(){
		System.out.println("Login");
	}
	@Test
	public void aoPriority2(){
		System.out.println("noPriority2");
	}
	@Test
	public void aoPriority1(){
		System.out.println("noPriority1");
	}

}
