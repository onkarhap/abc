package dayanandTuto;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AlertBox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver d= new FirefoxDriver();
		String url="file:///D:/Users/ankurgup/Desktop/Old%20Firefox/Selenium/Selenium%20Installations/Selenium%20Demos%20&%20Lab%20files/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/AlertExample.html";
		d.get(url);
		WebElement t=d.findElement(By.name("btnAlert"));
		t.click();
		
		Alert s=d.switchTo().alert();
		String at=s.getText();
		
		System.out.println("Alert text is "+at);
		s.accept();
	}

}
