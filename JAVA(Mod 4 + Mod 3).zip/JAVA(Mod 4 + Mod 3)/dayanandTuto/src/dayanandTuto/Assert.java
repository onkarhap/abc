package dayanandTuto;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class Assert {
	public void method(){
		
		String str1=new String("abc");
		String str2=new String("abc");
		String str3=null;
		String str4="abc";
		String str5="abc";
		int val1=6;
		int val2=5;
		String[] expectarray={"one","two","three"};
		String[] resultarray={"one","two","three"};
		//check 2 objects are equal
		assertEquals(str1,str2);
		//check cond is true
		assertTrue(val1>val2);
		//check cond is false
		assertFalse(val1>val2);
		//check obj not null
		assertNotNull(str1);
		//check obj null
		assertNull(str3);
		//check 2 obj preferences point 2 same obj
		assertSame(str4,str5);
		assertNotSame(str1,str3);
		assertArrayEquals(expectarray,resultarray);
		
		}	
}
