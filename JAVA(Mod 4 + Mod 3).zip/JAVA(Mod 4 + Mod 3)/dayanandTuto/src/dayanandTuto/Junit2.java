package dayanandTuto;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;


public class Junit2 {
	@Test
	public void b(){
		System.out.println("Test 1");
	}
	
	@Test
	public void a(){
		System.out.println("Test 2");
	}
	
	@AfterClass
	public static void After(){
		System.out.println("After Class");
	}
}
