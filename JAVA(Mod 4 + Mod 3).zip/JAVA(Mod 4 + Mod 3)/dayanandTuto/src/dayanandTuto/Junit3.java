package dayanandTuto;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Ignore;

public class Junit3 {
	@BeforeClass
	public static void initializeClass(){
		System.out.println("Before Class");
	}
	
	@Before
	public void initialize(){
		System.out.println("Before");
	}
	
	@Test
	public void Test2(){
		System.out.println("Test 2");
	}
	
	@Test
	public void Test1(){
		System.out.println("Test 1");
	}
	
	@Ignore
	@Test
	public void Test3(){
		System.out.println("Test 3");
	}
	
	@After
	public void After(){
		System.out.println("After");
	}
	
	@AfterClass
	public static void AfterClass(){
		System.out.println("After Class");
	}

}
