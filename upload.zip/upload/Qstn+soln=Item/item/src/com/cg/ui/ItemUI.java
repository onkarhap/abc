package com.cg.ui;

public class ItemUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
