package com.cg.helper;

public class Validator {
	public static boolean validateID(String id){
		return true;
	}
	public static boolean validateName(String name){
		return true;
	}
	public static boolean validatePrice(String price){
		return true;
	}

}
