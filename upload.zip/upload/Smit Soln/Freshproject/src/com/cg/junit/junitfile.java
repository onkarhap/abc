package com.cg.junit;

public class junitfile {

}
