package com.cg.ui;

import java.util.Scanner;

import com.cg.bin.*;
import static java.lang.System.out;


public class Item_ui {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice;
		Scanner sc=new Scanner(System.in);
		  while(true)
		{
			out.println("Enter your choice");
			out.println("1----Add Details");
			out.println("2----Display Details");
			out.println("3---- Count Of Records");
			out.println("4----Delete Record");
			out.println("5----Exit");
			
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:{System.out.println("Add Details");
				break;}
			
			case 2:{System.out.println("display details");
			break;
			}
			case 3:{System.out.println("Count of records");
			break;
			}
			case 4:{System.out.println("Delete Record");
			break;
			}
			default:
			{System.out.println("Exit");}
			
		}
		

	}

}
}
